cd /home/wu3yy/YYW/DER-mammoth   # adjust to your path
CUDA_VISIBLE_DEVICES=6,7 \
model="derpp"
dataset="seq-cifar100"
buffer_size=500          # adjust if needed
LR=0.03
alpha=0.1
beta=0.5
seeds=(0 1 2)
log_prefix="${model}_${dataset}"

for s in "${seeds[@]}"; do
  log_file="${log_prefix}_seed${s}.log"
  echo "Running model=${model}, dataset=${dataset}, seed=${s}, log=${log_file}"

  python main.py \
    --model "${model}" \
    --dataset "${dataset}" \
    --buffer_size "${buffer_size}" \
    --lr "${LR}" \
    --alpha "${alpha}" \
    --beta "${beta}" \
    --enable_other_metrics 1 \
    --batch_size 64 \
    --n_epochs 50 \
    --seed $s \
    --base_path /home/zhao3y3/Yuanyuanwu/DER/DER/data/ \
    2>&1 | tee "${log_file}"
done

