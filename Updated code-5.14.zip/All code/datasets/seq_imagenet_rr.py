import logging
try:
    import requests
except ImportError as e:
    logging.error("Please install requests using 'pip install requests'")
    raise e

import os
import torchvision.transforms as transforms # type: ignore[import-untyped]
import torch.nn.functional as F
from torch.utils.data import Dataset
import numpy as np
import pickle
from PIL import Image
from typing import List, Tuple

import yaml

from datasets.utils import set_default_from_args
from utils.conf import base_path
from datasets.utils.continual_dataset import ContinualDataset, fix_class_names_order, store_masked_loaders
from datasets.transforms.denormalization import DeNormalize
from torchvision.transforms.functional import InterpolationMode # type: ignore[import-untyped]


def _load_imagenet_r_from_folders(root: str, train: bool) -> Tuple[np.ndarray, np.ndarray, List[str]]:
    """
    Load image paths and targets from root/train and root/test with class subdirs.
    Returns (data, targets, class_names) with class_names sorted for consistent indexing.
    """
    split = 'train' if train else 'test'
    split_dir = os.path.join(root, split)
    if not os.path.isdir(split_dir):
        raise FileNotFoundError(f'Dataset folder not found: {split_dir}. Expected structure: {root}/train/<classes>/ and {root}/test/<classes>/')

    # Discover all class names (subdirs) and sort for consistent label indexing
    class_names = sorted([d for d in os.listdir(split_dir) if os.path.isdir(os.path.join(split_dir, d))])
    name_to_idx = {name: i for i, name in enumerate(class_names)}

    data = []
    targets = []
    for cls_name in class_names:
        cls_dir = os.path.join(split_dir, cls_name)
        for fname in os.listdir(cls_dir):
            path = os.path.join(cls_dir, fname)
            if os.path.isfile(path) and fname.lower().endswith(('.jpg', '.jpeg', '.png', '.webp', '.bmp')):
                data.append(path)
                targets.append(name_to_idx[cls_name])

    return np.array(data), np.array(targets), class_names


class MyImagenetR(Dataset):
    N_CLASSES = 200

    """
    Overrides the CIFAR100 dataset to change the getitem function.
    Supports two formats:
    - YAML: original imagenet-r with imagenet-r_train.yaml / imagenet-r_test.yaml (paths + targets).
    - Folder: root/train/<class_name>/ and root/test/<class_name>/ with images inside each class dir.
    """

    def __init__(self, root, train=True, transform=None,
                 target_transform=None, download=False,
                 use_folder_structure: bool = False) -> None:

        self.root = os.path.expanduser(root)
        self.train = train
        self.transform = transform
        self.target_transform = target_transform
        self.use_folder_structure = use_folder_structure

        self.not_aug_transform = transforms.Compose([transforms.Resize((224, 224), interpolation=InterpolationMode.BICUBIC), transforms.ToTensor()])

        if use_folder_structure:
            self.data, self.targets, self.folder_class_names = _load_imagenet_r_from_folders(self.root, self.train)
            return

        if not os.path.exists(self.root):
            if download:
                os.makedirs(self.root, exist_ok=True)
                # download from https://people.eecs.berkeley.edu/~hendrycks/imagenet-r.tar
                logging.info("Downloading imagenet-r dataset...")
                url = 'https://people.eecs.berkeley.edu/~hendrycks/imagenet-r.tar'
                r = requests.get(url, allow_redirects=True)
                if not os.path.exists(self.root):
                    os.makedirs(self.root)
                logging.info("Writing tar on disk...")
                open(self.root + 'imagenet-r.tar', 'wb').write(r.content)
                logging.info("Extracting tar...")
                os.system('tar -xf ' + self.root + 'imagenet-r.tar -C ' + self.root.rstrip('imagenet-r'))

                # move all files in imagenet-r to root with shutil
                import shutil
                logging.info("Moving files...")
                for d in os.listdir(self.root + 'imagenet-r'):
                    shutil.move(self.root + 'imagenet-r/' + d, self.root)

                logging.info("Cleaning up...")
                os.remove(self.root + 'imagenet-r.tar')
                os.rmdir(self.root + 'imagenet-r')

                logging.info("Done!")
            else:
                raise RuntimeError('Dataset not found.')

        pwd = os.path.dirname(os.path.abspath(__file__))
        if self.train:
            data_config = yaml.load(open(pwd + '/imagenet_r_utils/imagenet-r_train.yaml'), Loader=yaml.Loader)
        else:
            data_config = yaml.load(open(pwd + '/imagenet_r_utils/imagenet-r_test.yaml'), Loader=yaml.Loader)

        self.data = np.array(data_config['data'])
        self.targets = np.array(data_config['targets'])

    def __len__(self):
        return len(self.targets)

    def __getitem__(self, index: int) -> Tuple[Image.Image, int, Image.Image]:
        """
        Gets the requested element from the dataset.
        :param index: index of the element to be returned
        :returns: tuple: (image, target) where target is index of the target class.
        """
        img, target = self.data[index], self.targets[index]

        img = Image.open(img).convert('RGB')

        original_img = img.copy()

        not_aug_img = self.not_aug_transform(original_img)

        if self.transform is not None:
            img = self.transform(img)

        if self.target_transform is not None:
            target = self.target_transform(target)

        if not self.train:
            return img, target

        if hasattr(self, 'logits'):
            return img, target, not_aug_img, self.logits[index]

        return img, target, not_aug_img


class SequentialImagenetR(ContinualDataset):

    NAME = 'seq-imagenet-rr'
    SETTING = 'class-il'
    N_TASKS = 10
    N_CLASSES = 200
    N_CLASSES_PER_TASK = N_CLASSES // N_TASKS
    MEAN, STD = (0.0, 0.0, 0.0), (1.0, 1.0, 1.0)
    SIZE = (224, 224)

    TRANSFORM = transforms.Compose([
        transforms.RandomResizedCrop(SIZE[0], interpolation=InterpolationMode.BICUBIC),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize(mean=MEAN, std=STD),
    ])
    TEST_TRANSFORM = transforms.Compose([transforms.Resize(size=(256, 256),
                                                           interpolation=InterpolationMode.BICUBIC),
                                         transforms.CenterCrop(SIZE[0]),
                                         transforms.ToTensor(),
                                         transforms.Normalize(mean=MEAN, std=STD)])

    def __init__(self, args, dataset_path: str = None):
        super().__init__(args)
        self._dataset_path = dataset_path
        self._use_folder_structure = None
        self._folder_class_names = None

    def get_data_loaders(self):
        root = (self._dataset_path or (base_path() + 'imagenet-r/')).rstrip(os.sep) + os.sep
        # Auto-detect folder structure: root has train/ and test/ with class subdirs
        train_dir = os.path.join(root, 'train')
        test_dir = os.path.join(root, 'test')
        use_folder = (os.path.isdir(train_dir) and os.path.isdir(test_dir) and
                      any(os.path.isdir(os.path.join(train_dir, d)) for d in os.listdir(train_dir)))
        self._use_folder_structure = use_folder

        if use_folder:
            train_dataset = MyImagenetR(root, train=True, download=False,
                                        use_folder_structure=True, transform=self.TRANSFORM)
            test_dataset = MyImagenetR(root, train=False, download=False,
                                      use_folder_structure=True, transform=self.TEST_TRANSFORM)
            # Store class names from train (same order as in _load_imagenet_r_from_folders)
            self._folder_class_names = train_dataset.folder_class_names
            # Allow different N_CLASSES when using custom folder dataset
            n_classes = len(self._folder_class_names)
            if n_classes != self.N_CLASSES:
                logging.info(f'Using folder dataset with {n_classes} classes (seq-imagenet-r default is {self.N_CLASSES})')
                self.N_CLASSES = n_classes
                self.N_CLASSES_PER_TASK = n_classes // self.N_TASKS
        else:
            train_dataset = MyImagenetR(root, train=True, download=True, transform=self.TRANSFORM)
            test_dataset = MyImagenetR(root, train=False, download=True, transform=self.TEST_TRANSFORM)

        train, test = store_masked_loaders(train_dataset, test_dataset, self)
        return train, test

    def get_class_names(self):
        if self.class_names is not None:
            return self.class_names
        if self._use_folder_structure and self._folder_class_names is not None:
            class_names = [x.replace('_', ' ') for x in self._folder_class_names]
            class_names = fix_class_names_order(class_names, self.args)
            self.class_names = class_names
            return self.class_names

        pwd = os.path.dirname(os.path.abspath(__file__))
        with open(pwd + '/imagenet_r_utils/label_to_class_name.pkl', 'rb') as f:
            label_to_class_name = pickle.load(f)
        class_names = label_to_class_name.values()
        class_names = [x.replace('_', ' ') for x in class_names]

        class_names = fix_class_names_order(class_names, self.args)
        self.class_names = class_names
        return self.class_names

    @staticmethod
    def get_transform():
        transform = transforms.Compose(
            [transforms.ToPILImage(), SequentialImagenetR.TRANSFORM])
        return transform

    @set_default_from_args("backbone")
    def get_backbone():
        return "vit"

    @staticmethod
    def get_loss():
        return F.cross_entropy

    @staticmethod
    def get_normalization_transform():
        return transforms.Normalize(mean=SequentialImagenetR.MEAN, std=SequentialImagenetR.STD)

    @staticmethod
    def get_denormalization_transform():
        transform = DeNormalize(SequentialImagenetR.MEAN, SequentialImagenetR.STD)
        return transform

    @set_default_from_args('n_epochs')
    def get_epochs(self):
        return 50

    @set_default_from_args('batch_size')
    def get_batch_size(self):
        return 128
