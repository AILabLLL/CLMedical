import numpy as np
from PIL import Image

class MacenkoNormalizer:
    """
    纯 numpy 实现的 Macenko stain normalizer。
    参考 Macenko 等人提出的算法，用于 H&E 病理切片的染色归一化。
    不依赖 staintools / spams。
    """
    def __init__(self, Io: float = 240.0, alpha: float = 0.1, beta: float = 0.15):
        """
        Args:
            Io: 入射光强度常数（一般 240 或 255）
            alpha: 百分位参数（控制 stain 向量的范围）
            beta: OD 阈值，小于此值的像素视为背景
        """
        self.Io = Io
        self.alpha = alpha
        self.beta = beta

        self.HE_ref = None      # 参考 stain matrix（3x2）
        self.maxC_ref = None    # 参考 stain 浓度的 99 百分位，用于缩放

    # ---------- 工具函数 ----------

    def _rgb2od(self, I: np.ndarray) -> np.ndarray:
        I = I.astype(np.float32)
        I[I == 0] = 1
        OD = -np.log(I / self.Io)
        OD = np.clip(OD, 0, 6)  # ★★ 防止数值过大
        return OD

    def _od2rgb(self, OD: np.ndarray) -> np.ndarray:
        OD = np.clip(OD, 0, 6)  # ★★ 再保险一次
        I = self.Io * np.exp(-OD)
        I = np.clip(I, 0, 255).astype(np.uint8)
        return I

    # ---------- 拟合参考图像 ----------

    def fit(self, I_ref: np.ndarray):
        """
        用一张参考图像拟合 stain matrix 和参考浓度分布。
        I_ref: uint8 RGB, shape [H,W,3]
        """
        OD = self._rgb2od(I_ref)

        # 只保留非背景像素（OD 任一通道大于 beta）
        mask = (OD > self.beta).any(axis=2)
        OD_hat = OD[mask]  # [N,3]

        # SVD 求前两主成分（stain 平面）
        # OD_hat^T = U S V^T => 取 V 的前两列
        _, _, Vt = np.linalg.svd(OD_hat, full_matrices=False)
        # stain plane 的基向量
        V = Vt[:2, :].T  # [3,2]

        # 在 stain 平面上投影
        proj = np.dot(OD_hat, V)  # [N,2]
        # 计算角度
        phi = np.arctan2(proj[:, 1], proj[:, 0])

        # 取 alpha 与 100-alpha 百分位作为 H/E 的两个方向
        min_phi = np.percentile(phi, self.alpha)
        max_phi = np.percentile(phi, 100 - self.alpha)

        v1 = np.dot(V, np.array([np.cos(min_phi), np.sin(min_phi)]))
        v2 = np.dot(V, np.array([np.cos(max_phi), np.sin(max_phi)]))

        # 归一化为单位向量
        v1 /= np.linalg.norm(v1)
        v2 /= np.linalg.norm(v2)

        HE = np.stack((v1, v2), axis=1)  # [3,2]

        # 确保 H 在第一列（可选稳定性操作）
        if HE[0, 0] < HE[0, 1]:
            HE = HE[:, [1, 0]]

        self.HE_ref = HE  # [3,2]

        # 计算参考图像的 stain 浓度分布
        OD_flat = OD.reshape((-1, 3)).T  # [3,N]
        # C_ref: [2,N]
        C_ref, _, _, _ = np.linalg.lstsq(self.HE_ref, OD_flat, rcond=None)

        # 记录 99 百分位作为最大浓度
        self.maxC_ref = np.percentile(C_ref, 99, axis=1)  # [2]

    # ---------- 对新图像应用归一化 ----------

    def transform(self, I: np.ndarray) -> np.ndarray:
        """
        对输入图像 I 进行 stain normalization。
        I: uint8 RGB, shape [H,W,3]
        """
        if self.HE_ref is None or self.maxC_ref is None:
            raise RuntimeError("MacenkoNormalizer 还没有 fit 参考图像")

        OD = self._rgb2od(I)
        h, w, _ = OD.shape
        OD_flat = OD.reshape((-1, 3)).T  # [3,N]

        # 估计当前图像的 stain 浓度 C: [2,N]
        C, _, _, _ = np.linalg.lstsq(self.HE_ref, OD_flat, rcond=None)

        # 对浓度做缩放，使其分布与参考接近
        maxC = np.percentile(C, 99, axis=1)  # [2]
        # 避免除零
        maxC[maxC == 0] = 1e-6
        C_scaled = C * (self.maxC_ref[:, None] / maxC[:, None])

        # 重构 OD
        OD_hat = np.dot(self.HE_ref, C_scaled).T.reshape((h, w, 3))
        # 转回 RGB
        I_hat = self._od2rgb(OD_hat)
        return I_hat


class MacenkoStainNormalize(object):
    """
    给 torchvision.transforms 使用的包装器：
    在 __init__ 里拟合参考图；
    在 __call__ 中对每张图做 Macenko 归一化。
    """
    def __init__(self, ref_image_path: str):
        self.normalizer = MacenkoNormalizer()

        ref = Image.open(ref_image_path).convert("RGB")
        ref_np = np.array(ref)
        self.normalizer.fit(ref_np)

    def __call__(self, img: Image.Image) -> Image.Image:
        img_np = np.array(img.convert("RGB"))
        img_norm = self.normalizer.transform(img_np)
        return Image.fromarray(img_norm)
