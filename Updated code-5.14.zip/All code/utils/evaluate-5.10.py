import logging
from typing import TYPE_CHECKING, Any, Callable, Tuple
import torch
import numpy as np
from sklearn.metrics import roc_curve, auc
from sklearn.preprocessing import label_binarize
from tqdm.auto import tqdm

if TYPE_CHECKING:
    from models.utils.continual_model import ContinualModel
    from datasets.utils.continual_dataset import ContinualDataset


def mask_classes(outputs: torch.Tensor, dataset: 'ContinualDataset', k: int) -> None:
    """
    Given the output tensor, the dataset at hand and the current task,
    masks the former by setting the responses for the other tasks at -inf.
    It is used to obtain the results for the task-il setting.

    Args:
        outputs: the output tensor
        dataset: the continual dataset
        k: the task index
    """
    num_classes = dataset.N_CLASSES
    start_c, end_c = dataset.get_offsets(k)
    outputs[:, :start_c] = -float('inf')
    outputs[:, end_c:num_classes] = -float('inf')


# Type alias for the evaluation function
EvalFn = Callable[
    ['ContinualModel', 'ContinualDataset', bool, bool],
    Any
]


@torch.no_grad()
def evaluate(model: 'ContinualModel', dataset: 'ContinualDataset', last=False, return_loss=False, print_confusion=False, print_roc=False) -> Tuple[list, list]:
    """
    Evaluates the single-class top-1 accuracy of the model for each past task.

    The accuracy is evaluated for all the tasks up to the current one, only for the total number of classes seen so far.

    Args:
        model: the model to be evaluated
        dataset: the continual dataset at hand
        last: a boolean indicating whether to evaluate only the last task
        return_loss: a boolean indicating whether to return the loss in addition to the accuracy

    Returns:
        a tuple of lists, containing the class-il and task-il accuracy for each task. If return_loss is True, the loss is also returned as a third element.
    """
    status = model.net.training
    model.net.eval()
    accs, accs_mask_classes = [], []
    n_classes = dataset.get_offsets()[1]
    confusion = np.zeros((n_classes, n_classes), dtype=np.int64) if print_confusion else None
    all_labels = [] if print_roc else None
    all_scores = [] if print_roc else None
    loss_fn = dataset.get_loss()
    avg_loss = 0
    tot_seen_samples = 0
    total_len = sum(len(x) for x in dataset.test_loaders) if hasattr(dataset.test_loaders[0], '__len__') else None

    pbar = tqdm(dataset.test_loaders, total=total_len, desc='Evaluating', disable=model.args.non_verbose)
    for k, test_loader in enumerate(dataset.test_loaders):
        if last and k < len(dataset.test_loaders) - 1:
            continue
        correct, correct_mask_classes, total = 0.0, 0.0, 0.0
        test_iter = iter(test_loader)
        i = 0
        while True:
            try:
                data = next(test_iter)
            except StopIteration:
                break
            if model.args.debug_mode and i > model.get_debug_iters():
                break
            inputs, labels = data[0], data[1]
            inputs, labels = inputs.to(model.device), labels.to(model.device)
            if 'class-il' not in model.COMPATIBILITY and 'general-continual' not in model.COMPATIBILITY:
                outputs = model(inputs, k)
            else:
                if model.args.eval_future and k >= model.current_task:
                    outputs = model.future_forward(inputs)
                else:
                    outputs = model(inputs)

            if return_loss:
                loss = loss_fn(outputs, labels)
                avg_loss += loss.item()

            _, pred = torch.max(outputs[:, :n_classes].data, 1)
            correct += torch.sum(pred == labels).item()
            total += labels.shape[0]

            if print_roc:
                scores = torch.softmax(outputs[:, :n_classes], dim=1)
                all_labels.append(labels.cpu().numpy())
                all_scores.append(scores.cpu().numpy())

            if print_confusion:
                y_true = labels.cpu().numpy()
                y_pred = pred.cpu().numpy()
                for t, p in zip(y_true, y_pred):
                    confusion[t, p] += 1


            i += 1
            pbar.set_postfix({f'acc_task_{k+1}': max(0, correct / total * 100)}, refresh=False)
            pbar.set_description(f"Evaluating Task {k+1}", refresh=False)
            pbar.update(1)

            if dataset.SETTING == 'class-il':
                mask_classes(outputs, dataset, k)
                _, pred = torch.max(outputs.data, 1)
                correct_mask_classes += torch.sum(pred == labels).item()

        tot_seen_samples += total

        if correct > correct_mask_classes and dataset.SETTING == 'class-il':
            logging.warning("Task-IL accuracy is LOWER than Class-IL accuracy. "
                            "This should NEVER happen and probably means there is a bug somewhere. "
                            "Hint: check if the dataloader returns the targets in the correct order.")
        accs.append(correct / total * 100
                    if 'class-il' in model.COMPATIBILITY or 'general-continual' in model.COMPATIBILITY else 0)
        accs_mask_classes.append(correct_mask_classes / total * 100)
    pbar.close()

    if print_confusion:
        logging.info(f"Confusion matrix (Class-IL, seen classes 0-{n_classes - 1}):\n{confusion}")

    if print_roc:
        all_labels = np.concatenate(all_labels)
        all_scores = np.concatenate(all_scores)

        y_true_bin = label_binarize(all_labels, classes=np.arange(n_classes))

        logging.info(f"ROC curve representative points (10) (Class-IL, seen classes 0-{n_classes - 1}):")
        for c in range(n_classes):
            class_targets = y_true_bin[:, c]

            # 安全保护：如果当前类没有正样本或没有负样本，则跳过
            if class_targets.sum() == 0 or class_targets.sum() == len(class_targets):
                logging.info(f"Class {c} | ROC skipped (insufficient positive/negative samples)")
                continue

            fpr, tpr, _ = roc_curve(class_targets, all_scores[:, c])
            roc_auc = auc(fpr, tpr)

            num_points = min(10, len(fpr))
            sample_idx = np.linspace(0, len(fpr) - 1, num_points, dtype=int)
            sample_idx = np.unique(sample_idx)

            logging.info(f"Class {c} | AUC = {roc_auc:.4f}")
            for idx in sample_idx:
                logging.info(f"  ({fpr[idx]:.4f}, {tpr[idx]:.4f})")

    model.net.train(status)
    if return_loss:
        return accs, accs_mask_classes, avg_loss / tot_seen_samples
    return accs, accs_mask_classes
